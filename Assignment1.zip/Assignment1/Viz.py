# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 21:16:19 2019

@author: LENOVO
"""

import numpy as np
import matplotlib.pyplot as plt
 
# set width of bar
barWidth = 0.2
 
# set height of bar
bars1 = [0.91217 ,0.89 ,0.9165 ,0.95652]
bars2 = [0.69736 ,0.8026 ,0.63157 ,0.73684]
bars3 = [0.93 , 0.9 ,0.92 ,0.92]
bars4 = [0.9436 , 0.8546 , 0.8814 , 0.8814]


# Set position of bar on X axis
r1 = np.arange(len(bars1))
r2 = [x + barWidth for x in r1]
r3 = [x + barWidth for x in r2]
r4 = [x + barWidth for x in r3] 
# Make the plot
plt.bar(r1, bars1, color='#7CFC00', width=barWidth, edgecolor='white', label='SpamBase')
plt.bar(r2, bars2, color='#FFD700', width=barWidth, edgecolor='white', label='Heart Disease')
plt.bar(r3, bars3, color='#F08080', width=barWidth, edgecolor='white', label='Social network Ads')
plt.bar(r4, bars3, color='#000080', width=barWidth, edgecolor='white', label='Letter Recognition')

        
# Add xticks on the middle of the group bars
plt.ylabel("Accuracy")
plt.title("Models Comparison",loc='center')
plt.xlabel('Models', fontweight='bold')
plt.xticks([r + barWidth for r in range(len(bars1))], ['KNN', 'SVM', 'Decision Tree', 'Random Forest'])
 
# Create legend & Show graphic
plt.legend()
plt.show()
