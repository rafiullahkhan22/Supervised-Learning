
# Regression Template

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('Age_mod.csv')
dataset=dataset.drop(['Sex'],axis=1)
X = dataset.iloc[:, :-1].values
y = dataset.iloc[: , -1].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
'''sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)
y_test = sc_y.transform(y_test)'''


# Fitting SVR to the dataset
from sklearn.svm import SVR
regressor = SVR(kernel='linear',degree=1)
regressor.fit(X, y)

# Predicting a new result
y_pred = regressor.predict(X_test)

from sklearn import metrics
print('MAE: ', metrics.mean_absolute_error(y_test,y_pred))
print('MSE: ', metrics.mean_absolute_error(y_test,y_pred))
print('RMSE: ', np.sqrt(metrics.mean_absolute_error(y_test,y_pred)))

# Visualising the Regression results
plt.scatter(dataset['Shucked weight'],dataset['Shell weight'] , color = 'red')
plt.plot(X, regressor.predict(X), color = 'blue')
plt.title('Age_mod (Regression Model)')
plt.xlabel('Shucked weight')
plt.ylabel('ring')
plt.show()

