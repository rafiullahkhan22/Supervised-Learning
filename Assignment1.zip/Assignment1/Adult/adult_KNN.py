# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 21:54:19 2019

@author: LENOVO
"""


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('adult.data')
X = dataset.iloc[:,:14].values
y = dataset.iloc[:, -1].values
#missing values
from sklearn.preprocessing import Imputer
imputer = Imputer(strategy = 'median', axis = 0)
imputer = imputer.fit(X[:, 1])
X[:, 1] = imputer.transform(X[:, 1])