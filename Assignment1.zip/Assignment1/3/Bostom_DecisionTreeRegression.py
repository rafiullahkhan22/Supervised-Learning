# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 01:11:57 2019

@author: LENOVO
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 23:35:32 2019

@author: Samreen
"""

import numpy as np
import pandas as pd

from sklearn.datasets import load_boston
#boston_dataset = load_boston()

dataset = pd.read_csv('boston.csv')

X = dataset.iloc[:,1:13].values
y = dataset.iloc[:, -1].values

#boston = pd.DataFrame(boston_dataset.data, columns=boston_dataset.feature_names)
#boston.head()

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size =0.25, random_state = 0)

# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)

# Fitting Decision Tree Regression to the dataset
from sklearn.tree import DecisionTreeRegressor
regressor = DecisionTreeRegressor(random_state = 0)
regressor.fit(X_train, y_train)

# Predicting a new result
y_pred = regressor.predict(X_test)
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn import metrics

print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))  
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))  
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))

'''
import statsmodels.formula.api as sm
X=np.append(arr= np.ones((506,1)).astype(int),values=X,axis =1)

X_opt = X[:, [0,1,2,3,4,5,6,7,8,9,10,11,12]]
regressor_OLS = sm.OLS(endog = y, exog= X_opt).fit()
regressor_OLS.summary()

X_opt = X[:, [0,1,3,4,5,6,7,8,9,10,11,12]]
regressor_OLS = sm.OLS(endog = y, exog= X_opt).fit()
regressor_OLS.summary()
'''