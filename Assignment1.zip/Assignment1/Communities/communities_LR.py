# -*- coding: utf-8 -*-
"""
Created on Thu Apr 25 01:29:38 2019

@author: LENOVO
"""

import numpy as np
import pandas as pd

from sklearn.datasets import load_boston
#boston_dataset = load_boston()

dataset = pd.read_csv('communities.data')
X = dataset.iloc[:,:127].values
y = dataset.iloc[:, -1].values
# Encoding categorical data
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder = LabelEncoder()
X[:, 3] = labelencoder.fit_transform(X[:, 3])
onehotencoder = OneHotEncoder(categorical_features = [3])
#X = onehotencoder.fit_transform(X).toarray()
# Taking care of missing data
from sklearn.preprocessing import Imputer
imputer = Imputer(missing_values = 'NaN', strategy = 'most_frequent', axis = 0)
imputer = imputer.fit(X[:, 0:126])
X[:, 0:126] = imputer.transform(X[:, 0:126])


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size =0.25, random_state = 0)


from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
regressor.fit(X_train,y_train)

y_pred = regressor.predict(X_test)
